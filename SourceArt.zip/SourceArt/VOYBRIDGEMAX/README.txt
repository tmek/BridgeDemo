Chainsaw_NL presents the "USS Voager Bridge"

It took a year to complete this project for several reasons.

1. I started in google sketchup... Dumb i know.
2. All screens had to be made. I now know Illustrator aswell :)
3. I'm a sucker for detail.


Legal

This mesh remains the property of Chainsaw_NL and Star trek Meshes.  
It however may be used to create images and scenes for non-profit use only.

Any images produced with this mesh do NOT have to be credited to the mesh author. But it would be nice.

Star Trek and Enterprise are copyright Paramount Pictures.  

Any violation may result in the restriction of this and future meshes.


Illustrator LCARS screen files are available on request sticky170@gmail.com




                                                                          `d+                                                                         
                                                                         .dMM/                                                                        
                                                                        .mMMMM/                                                                       
                                                                  `.-::/mMMMMMM+-.`                                                                   
                                       `-//               `-/oyhmNNNNMMMMMMMMMMMMNNNmhyo/-`               :/-`                                        
                                .:  -odNNd.          `-+ymNNMMMNmdhysdMMMMMMMMMMMdhdmNMMMNNmy+:`          `hMNdo:  --                                 
                              -hNh+dNMMMy`       `-ohNNMMNdyo:-```  :NMMMMMMMMMMMN-```.:+ydNMMMNho:`       `sMMMNmoyNh:                               
                             oNMMMMMMMm/      `:smNMMmh+-``        -NMMMMMMMMMMMMMm.      ``-+ymMMNmy/`      /mMMMMMMMNs```.--:::///////:::-.`        
                        .   yMMMMMMMNs.     -smMMNho-`            -NMMMMMMMMMMMMMMMh`          `-ohNMMms:     `sNMMMMMMMmmNNNNNMMMMMMMMMMMNNNNmds+-`  
                       +h  oMMMMMMms.    `/dNMMdo.`              .mMMMMMMMMMMMMMMMMMs              .+hNMNd+:+shmMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNmo`
                     `hMo .NMMNdy:`    `+mMMNs-`                `dMMMMMMMMMMMMMMMMMMM+               -oNMMMMMmdhhyyyydNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh
                    `dMM: .//-.`     `+mMMmo.                  `dMMMMMMMMMMMMMMMMMMMMN:            `://:-+dMMNo.     `.-://smMMMMMMMMMMMMMMMMMMMMMMMMN
                    yMMM.  `.-`     :dMMN+`                  `.hMMMMMMMMMMMMMMMMMMMMMMm.                  `+mMMm/      -.`  .NMMMMMMMMMMMMMMMMMMMMMMN/
               `s  .MMMMhydmh:    .yNMNs.            .-:/oshddmMMMMMMMMMMMMMMMMMMMMMMMMmdhso/:-.`           .sNMMy.    -ymdhyMMMMMMMMMMMMMMMMMMMMMMm: 
               sN  +MMMMMMm+`    :mMMd:        .-/oydmNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNmdhs/-.`       -dMMm/    `/mMMMMMMMMMMMMMMMMMMMMMMNs`  
              +MN  yMMMMd+.     +NMMs`    `./sdmNMMMMMMMMMMNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMmdy+-`    `oNMNo     `/mMMMMMMMMMMMMMMMMMMNs.    
             `NMM` hNmy:`      oMMN+   .:sdNMMMMMMMMMNmhs+::NMMMMMMMMMMMMMMMMMMMMMMMMMMMMm:/oydmNMMMMMMMMNmy+-`  /NMMs`    /mMMMMMMMMMMMMMMMMmo.      
         `   +MMM- :-`        sMMN/ ./hNMMMMMMMMNmy+:.`    sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM-    .-/sdmMMMMMMMMNdo-`:mMMy` -yMMMMMMMMMMMMMMMNm+.        
         o`  oMMM+  `.-:     oMMN/:yNMMMMMMMMmy/-`        :MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh         .:odNMMMMMMMMd+/NMMyyNMMMMMMMMMMMMMMmy/y          
         my  +MMMNhhdmN:    /MMMddMMMMMMMMms:`           `mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM-            -+dNMMMMMMMmmMMMMMMMMMMMMMMMMMMy. oN`         
        .MM: .MMMMMMMm-    .NMMMMMMMMMMNh/`              yMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy               -sNMMMMMMMMMMMMMMMMMMMMMMMMM- -MM-         
        :MMN` oMMMMms`     yMMMMMMMMMMh-                /MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM.                .sNMMMMMMMMMMMMMMMMmmMMMMs `mMM/         
        -MMMh` yNh/`      -MMMMMMMMMN/                 .NMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy                .+mMMMMMMMMMMMMMmy/``/yNh` yMMM/         
        `NMMMh` ```:o:    yMMMMMMMMd.                  hMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM.            `/hNMMMMMMMMMMMMMy/` -o:`````yMMMM.         
    :s   yMMMMm+shNMh    .NMMMMMMMd`                  +MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy         `/hNMMMMMMMMMMMMMMMM+    yMNds+dMMMMh   o/     
    :Mh` `mMMMMMMMMd`    sMMMMMMMM-                  .NMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM.     `+hNMMMMMMMMMMMMMMMMMMMN`   `hMMMMMMMMm. `yMo     
    :MMd. .dMMMMMMd`     mMMMMMMMd                   dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMs  .+hNMMMMMMMMMMMMmosMMMMMMMM:    `hMMMMMMm. `hMM/     
    -MMMN: `sMMMNs`     `MMMMMMMMh                  /MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMsdMMMMMMMMMMMMNh+-  -MMMMMMMM/      oNMMMy` -mMMM/     
    `NMMMMo  -yo.        mMMMMMMMm                 `mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMmy/`     oMMMMMMMM:       .oy-  +NMMMM`     
     sMMMMMd.     `y:    yMMMMMMMM:                oMMMMMMMMMMMMMMMMMMMMMMMMMMMMNMMMMMMMMMMMMMMMMMMMMMMdo-         mMMMMMMMm    -h.     .hMMMMMy      
  `s `mMMMMMMs` -yNN`    oMMMMMMMMN.              `NMMMMMMMMMMMMMMMMMMMMMMMMmy+. /NMMMMMMMMMMMMMMMMmy/`           sMMMMMMMMs     mMy: `oMMMMMMm` o.   
  `Nm-`hMMMMMMMmMMMo     :MMMMMMMMMm-             sMMMMMMMMMMMMMMMMMMMMMMdo-   -+hNMMMMMMMMMMMMMMo.             `yMMMMMMMMM/     +MMMmNMMMMMMd.-dM.   
   hMMs`+NMMMMMMMMd`     `NMMMMMMMMMN+           -MMMMMMMMMMMMMMMMMMMMh+. .:ohNMMMMMMMMMMMMMMMMMMo             -dMMMMMMMMMM.      hMMMMMMMMNo`oMMm    
   :MMMm:`+dMMMMMh`  `    yMMMMMMMMMMMd/         hMMMMMMMMMMMMMMMMMd+.-+ymNMMMMMMMMMMMMMMMMMMMMMMN`          .sMMMMMMMMMMMh    `  `yMMMMMdo`:dMMM+    
    hMMMMy- .+hd/   -s    -MMMsyMMMMMMMMm+.     :MMMMMMMMMMMMMMMMdsshNMMMMMMMMMMMMMmyo--dMMMMMMMMMo        :yNMMMMMMMmyMMM:    o:   :dho-`.yMMMMd     
    .mMMMMNs-  `   -Ny     yMMm`-yNMMMMMMMNh/.  dMMMMMMMMMMMMMMMMNMMMMMMMMMMMMNhs/-`    `+NMMMMMMMN`    -smMMMMMMMMd+`dMMh     sN:      .oNMMMMm.     
     .dMMMMMNh/. .oNMy     .NMMy  .odMMMMMMMMNhyMMMMMMMMMMMMMMMMMMMMMMMMMmhs/.`           .hMMMMMMMo./ymNMMMMMMMNy-` oMMN.     oMNs. ./yNMMMMMm-      
      `sNMMMMMMNmNMMM+      /MMM+   `-odMMMMMMMMMMMMMMMMMMMMMMMMMMMNdyo/.``                 /mMMMMMMNMMMMMMMMmy:`   /MMM+      /MMMNmNMMMMMMMy`       
     :` -yNMMMMMMMMMN`  `    +MMN/     `.+hNMMMMMMMMMMMMMMMMMMmhs+-``                  `.-/+smMMMMMMMMMMMmho-`     :NMMs    .  `mMMMMMMMMMNy- `:      
     :ms:`.+ymMMMMMN/  `h:    oMMN/ .-:+shmMMMMMMMMMMMMMMMMMMMNmhysoo+++/:::/+++oosyhdmmNNMMMMMMMMMMMdy+-`        :NMMs    .d`  :NMMMMMmy+.`-sm+      
      oMNd+. `.:/oo-   sMs  `.-dMMNmmNMMMMMMMMMMMMNhydmNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNdhhMMMo           +NMMs     +My   -oo+:.` .+dNMs       
`      +NMMNh+-   `..-oMMNhdmmNMMMMMMMMMNdhysMMMNy-  `..-/+syhddmNNMMMMMMMMMMMMMMMNNmmdhhso+:-.` `+NMm`        `sMMN+      hMMs`      ./hNMMMo        
.+osysssmMMMMMNdddmmNNMMMMMMMNNmddmMMMs-.`  +MMy-             ``...---:::::::::---...``            -hM+       :dMMm:       NMMMh:-:+sdNMMMMm/         
  `.-:+osyhmMMMMMMMMMMMMMM+:---`` `sNMNy.  `md:`                                                    `sm`    .sNMMy.   `    NMMMMMNMMMMMMMmo.          
         :ymMMMMMMMMMMMMMMdddddy/   :dMMNdddMmddddddddddddddddd-    +dddddddddd/            -hddddddddMy  .omMMMMddddddddddMMMMMMMMMMMMd+.            
        .NMMMMMmdddmNNNNNddNMMMMM/   `smMMMMMmmNMMMMMMNmmmmmmmm:    sMMMMMMMMMMN/          -mMMMMMMMMMMd.omMMNMMMMMMNMMMNNNNNNNNNMMMMMM-              
        :MMMMMs````..----``/hMMMd:    `.+dMMMh/:MMMMMd.````````     sMMMMN::dMMMN/        -mMMMN/-dMMMMNNMMm+oMMMMMs:NMN:--------sddddd.              
        :MMMMMo+s+:-..`````.sMMM+   `    `/hNMMdMMMMMh              sMMMMN  .dMMMN/      -mMMMN-  sMMMMMNh/` +MMMMM-/MMMy.`````..-:+so                
        -MMMMMNdMMMMNmmmmmmNMMMMd  `h.      -omNMMMMMh              sMMMMN   .mMMMN/    -mMMMN:`-omMMMMm-    +MMMMM-yMMMMNmmmmmmNMMmo`                
         +dmmmmmmmmmmNMMMMMMMMMMM/ .Mm:       `:NMMMMNho:.`         sMMMMN    .mMMMM/  -mMMMMhhmMMMMMMMd     +MMMMM-yMMMMMMMMMMNmh+.                  
           `````````.-/osyhdMMMMMo .MMN/        NMMMMMNMMNdho/-.``` sMMMMN     .mMMMMssNMMMMMMNmh+yMMMMd     oMMMMM-odddddhhso/:`                     
        `+++++-         ```-MMMMMo`/MMMN-       NMMMMh-/sdmNMMMNmdhymMMMMN++++osdMMMMMMMMMNds+-`  oMMMMd    .NMMMMM/`````````````/yyyyy.              
        -MMMMMNyssssssssdddmMMMMMmmNMMMMm    `  NMMMMh    `-:+sydmNNMMMMMMMMMMNNNNNMMMMMMM/       oMMMMd`   hMMMMMMMddddddddmddddMMMMMM-              
         omNNNNNNNNNNNNNNNNNNNNMMMMMMMMMM:  :myoNMMMNy            `.sNNNNm:::::--.:mNNNNN/        oMMMMNm  -MMMMMMMMMMNNNNNNNNNNNNNNNmo               
          `...................-/+ssyyyso+.  /MMMMMMmdy+/-.```       ``````         ````..```.:/+shmMMMMMN. ./osyyyss+/-..............                 
                                           +NNMMMMMMMMMMMMNmdhs+-`                  `:+yhmNMMMMMMMMMMMMMNd-                                           
                                            `.-::///////+osyhmNMMNh+.            -odNMNNmhyso+///////::-.                                             
                                                               .:oNMMh:        /dMMm+:.                                                               
                                                        :shhhddmNMMMMNo`      .yNMMMMmdddhhho.                                                        
                                                          :dMMNNmds+-            :oydmNNMMy.                                                          